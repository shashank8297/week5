package com.infnite.hikari;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.util.DriverDataSource;

//import javax.sql.DataSource;

//import com.zaxxer.hikari.HikariConfig;
//import com.zaxxer.hikari.HikariDataSource;
//import com.zaxxer.hikari.util.DriverDataSource;

public class Hikari {
	private static DataSource datasource = null;

	public static DataSource getDataSource(){
		if(datasource == null){
			HikariConfig config = new HikariConfig();
			//config.setDriverClassName("com.mysql.jdbc.Driver");
			config.setJdbcUrl("jdbc:mysql://localhost:3306/week5");
			config.setUsername("root");
			config.setPassword("mysql123@");
			config.setAutoCommit(false);
			config.addDataSourceProperty("cachePrepStmts", "true");
			config.addDataSourceProperty("PrepStmtsCacheSize","250");
			config.addDataSourceProperty("PrepStmtsCacheS1lLimit", "2048");
			datasource = new HikariDataSource(config);
		}
		return datasource;
	}
}
